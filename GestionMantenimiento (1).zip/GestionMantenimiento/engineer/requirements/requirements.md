# Requisitos del Sistema de Gestión de Mantenimiento

## Requisitos Funcionales

1. Gestión de Clientes
   - Agregar nuevos clientes
   - Ver lista de clientes
   - Actualizar información de clientes
   - Eliminar clientes

2. Gestión de Equipos
   - Registrar nuevos equipos
   - Asociar equipos a clientes
   - Ver lista de equipos
   - Actualizar información de equipos
   - Eliminar equipos

3. Gestión de Diagnósticos
   - Crear nuevos diagnósticos
   - Asociar diagnósticos a equipos
   - Ver lista de diagnósticos
   - Actualizar diagnósticos
   - Eliminar diagnósticos

4. Gestión de Facturas
   - Generar nuevas facturas
   - Asociar facturas a clientes y arreglos
   - Ver lista de facturas
   - Actualizar facturas
   - Eliminar facturas

5. Autenticación de Usuarios
   - Inicio de sesión
   - Cierre de sesión
   - Gestión de roles (Administrador, Técnico)

## Requisitos No Funcionales

1. Seguridad
   - Encriptación de contraseñas
   - Protección contra inyección SQL
   - Autenticación para acceder a todas las páginas del sistema

2. Usabilidad
   - Interfaz intuitiva y fácil de usar
   - Diseño responsivo para diferentes dispositivos

3. Rendimiento
   - Tiempo de carga de páginas menor a 3 segundos
   - Capacidad para manejar al menos 100 usuarios concurrentes

4. Mantenibilidad
   - Código modular y bien documentado
   - Uso de patrones de diseño para facilitar futuras expansiones

5. Compatibilidad
   - Funciona en los navegadores web más comunes (Chrome, Firefox, Safari, Edge)

