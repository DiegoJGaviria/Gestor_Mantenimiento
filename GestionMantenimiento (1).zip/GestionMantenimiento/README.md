# Sistema de Gestión de Mantenimiento de Computadoras

Este proyecto es un sistema de gestión para el mantenimiento de computadoras, desarrollado con PHP y MySQL.

## Requisitos previos

- XAMPP (o cualquier otro servidor local que soporte PHP y MySQL)
- MySQL Workbench (opcional, pero recomendado para la gestión de la base de datos)
- Node.js y npm (para ejecutar el proyecto con `npm start`)

## Configuración

1. Clona este repositorio en tu directorio de XAMPP (usualmente `htdocs`).

2. Inicia los servicios de Apache y MySQL en XAMPP.

3. Crea una base de datos en MySQL usando MySQL Workbench o phpMyAdmin.

4. Importa el archivo `init_db.sql` en tu base de datos recién creada. Esto creará las tablas necesarias y añadirá algunos datos iniciales.

5. Copia el archivo `.env.example` a `.env` y actualiza las variables con tus credenciales de base de datos:

