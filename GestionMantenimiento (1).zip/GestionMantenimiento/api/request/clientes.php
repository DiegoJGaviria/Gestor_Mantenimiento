<?php
require_once '../database/db_connection.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $sql = "SELECT * FROM Clientes";
    $result = $conn->query($sql);

    $clientes = [];
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $clientes[] = $row;
        }
    }

    echo json_encode($clientes);
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $conn->real_escape_string($_POST['nombre']);
    $apellido = $conn->real_escape_string($_POST['apellido']);
    $correo = $conn->real_escape_string($_POST['correo']);
    $telefono = $conn->real_escape_string($_POST['telefono']);
    $direccion = $conn->real_escape_string($_POST['direccion']);

    $sql = "INSERT INTO Clientes (nombre_cliente, apeliido_cliente, correo_cliente, telefono_cliente, direccion_cliente) 
            VALUES ('$nombre', '$apellido', '$correo', '$telefono', '$direccion')";

    if ($conn->query($sql) === TRUE) {
        echo json_encode(['success' => true, 'message' => 'Cliente agregado con éxito']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error al agregar cliente: ' . $conn->error]);
    }
}

$conn->close();
?>

